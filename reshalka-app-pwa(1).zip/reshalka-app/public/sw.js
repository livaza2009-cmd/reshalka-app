const CACHE = 'reshalka-pwa-v1';
const CORE = ['/', '/manifest.webmanifest', '/icon.svg'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE)));
  self.skipWaiting();
});
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
  );
  self.clients.claim();
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  // Keep the app shell available offline. API/data is not cached.
  if (req.mode === 'navigate') {
    event.respondWith(fetch(req).then(res => {
      const copy = res.clone();
      caches.open(CACHE).then(cache => cache.put('/', copy));
      return res;
    }).catch(() => caches.match('/')));
  } else if (!new URL(req.url).pathname.startsWith('/api/')) {
    event.respondWith(caches.match(req).then(cached => cached || fetch(req)));
  }
});
